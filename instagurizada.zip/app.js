var MONGOHQ_URL="mongodb://instagurizada:diogola@paulo.mongohq.com:10041/app21251612"

 var express = require('express')
    , http = require('http')
    , https = require("https")
    , path = require('path')
    , mongoose = require("mongoose")
    , querystring = require('querystring')
    , _ = require('underscore')
    //, io = require('socket.io')
   // , logfmt = require("logfmt")
    , Instagram = require('instagram-node-lib');

    mongoose.connect(process.env.MONGOHQ_URL || MONGOHQ_URL);
    Photo = mongoose.model('Photo', { title: "string", url: "string" , thumb: "string", image:"string"});

    var insta = {
		client_id: 'a50b4ec7d94e456b8f1c7a1d7943844d',
		client_secret: '91106972724240e8896dff48327c3f83',
		callback_url: 'http://instagurizada.herokuapp.com/subscribe'
	}

	Instagram.set('client_id', insta.client_id);
	Instagram.set('client_secret', insta.client_secret);
	Instagram.set('callback_url', insta.callback);



var subscriptions = 'https://api.instagram.com/v1/subscriptions?client_secret=91106972724240e8896dff48327c3f83&client_id=a50b4ec7d94e456b8f1c7a1d7943844d'

var app = express();

//app.use(logfmt.requestLogger());

app.configure(function(){
    app.set('port', process.env.PORT || 8080);
    app.set('views', __dirname + '/views');
    app.set('view engine', 'ejs');
    app.use(express.bodyParser());
    app.use(express.methodOverride());
    app.use(express.cookieParser('diogola'));
    app.use(express.session());
    app.use(app.router);  
    app.use(require('stylus').middleware(__dirname + '/public'));
    app.use(express.static(path.join(__dirname, 'public')));
  });



app.get('/subscribe', function(req, res) {
  res.send(req.query['hub.challenge']);
  io.sockets.emit('test',req.query['hub.challenge'] );

/*
  Instagram.tags.recent({ name: 'formaturaegp' }, function(data){
		io.sockets.emit('photo', data);
		//console.log("CHEGOU FOTOS");
	}); 
  //res.render('basetext', { text: text });
  */
});


app.get('/add', function(req, res){

    Photo.find( {}, function(err, documents){
        if (err) res.send(500);
        res.render('form',  {writeSuccess: false, photos: documents});    

    });
    
});

  app.post('/add', function(req, res){
    
    var title = req.body.title;
    var url = req.body.url;
    var password = req.body.password;
    var transloadit = JSON.parse(req.body.transloadit)

    if (password != "diogola"){

      res.render('form', {url: url, title: title, writeSuccess: false});

    }else{ 


      for(i = 0; i < transloadit.uploads.length;i++){
          var photo = new Photo({
          title: title,
          url: transloadit.results.resize_to_amazon[i].url,
          image: transloadit.results.resize_to_amazon[i].url,
          thumb: transloadit.results.resize_to_75[i].url
        });

        photo.save(function(err){
            if (err) {
              res.render('form', {url: url, title: title, writeSuccess: false});
            }
        });

      } //endfor
      
      Photo.find( {}, function(err, documents){
        if (err) res.send(500);
        res.render('form',  {writeSuccess: true, photos: documents});    

      });
    }
  
});


app.post('/subscribe', function(request, response){
  // request.body is a JSON already parsed
 // request.body.forEach(function(notificationOjb){
    // Every notification object contains the id of the geography
    // that has been updated, and the photo can be obtained from
    // that geography
    var notificationOjb = {
    	object_id: 'formaturaegp'
    };

    https.get({
      host: 'api.instagram.com',
      path: '/v1/tags/' + notificationOjb.object_id + '/media/recent' +
      '?' + querystring.stringify({client_id: insta.client_id,count: 1}),
    }, function(res){

      var raw = "";

	      res.on('data', function(chunk) {
	        raw += chunk;
	      });

	      // When the whole body has arrived, it has to be a valid JSON, with data,
	      // and the first photo of the date must to have a location attribute.
	      // If so, the photo is emitted through the websocket
	      res.on('end', function() {
	        var response = JSON.parse(raw);
	        if(response['data'].length > 0) {


              
            for(i in response.data){

              var idata = {
                title: response.data[i].caption.text,
                url: response.data[i].images.standard_resolution.url,
                image: response.data[i].images.standard_resolution.url,
                thumb: response.data[i].images.thumbnail.url  
              }
              var photo = new Photo(idata);

              //Previne duplicatas
              Photo.find({url: idata.url}, function(err, documents){
                   if (err) res.send(500);
                   if(documents.length == 0){
                      photo.save(function(err){
                        if (err) {
                          console.log(err);
                        }else{
                          io.sockets.emit('photo', idata);
                        }
                      });

                   }
              });

            }//endfor
	        } 
	      });

    });
  //});

  response.send(200);
});



app.get('/', function(req, res) {
   Photo.find( {}, function(err, documents){
        if (err) res.send(500);
        res.render('index', { photos: documents });   
    });
});

app.get('/photos', function(req, res) {
   Photo.find( {}, function(err, documents){
        if (err) res.send(500);
        var output = _.map(documents, function(document){

          return{
            title: document.title,
            image: document.url,
            src: document.url,
            url: document.url,
            thumb: document.thumb
          }
        });

        res.send(output);   
    });
});

var sv = http.createServer(app);
var io = require('socket.io').listen(sv);
io.set('log level', 1); 

var port = process.env.PORT || 8080;
sv.listen(port, function() {
  console.log("Listening on " + port);
});

